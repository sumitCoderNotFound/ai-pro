import { useState } from 'react'
import { 
  Shield, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  MessageSquare,
  Phone,
  Clock,
  Star,
  Filter,
  Download,
  ChevronRight,
  Play,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react'

const QualityAssurancePage = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('7d')
  const [selectedAgent, setSelectedAgent] = useState('all')

  // Mock QA data
  const qaMetrics = {
    overallScore: 87,
    totalReviewed: 156,
    passed: 142,
    failed: 14,
    flagged: 8
  }

  const recentReviews = [
    {
      id: 1,
      conversationId: 'conv-123',
      type: 'voice',
      agent: 'Sales Assistant',
      score: 92,
      status: 'passed',
      duration: '3:24',
      timestamp: '2 hours ago',
      issues: []
    },
    {
      id: 2,
      conversationId: 'conv-124',
      type: 'chat',
      agent: 'Support Bot',
      score: 78,
      status: 'flagged',
      duration: '5:12',
      timestamp: '3 hours ago',
      issues: ['Response too long', 'Missed follow-up question']
    },
    {
      id: 3,
      conversationId: 'conv-125',
      type: 'voice',
      agent: 'Booking Agent',
      score: 45,
      status: 'failed',
      duration: '1:45',
      timestamp: '5 hours ago',
      issues: ['Incorrect information provided', 'Customer left confused']
    },
    {
      id: 4,
      conversationId: 'conv-126',
      type: 'chat',
      agent: 'Sales Assistant',
      score: 95,
      status: 'passed',
      duration: '4:30',
      timestamp: '6 hours ago',
      issues: []
    }
  ]

  const qaRules = [
    { name: 'Greeting Protocol', enabled: true, passRate: 98 },
    { name: 'Information Accuracy', enabled: true, passRate: 89 },
    { name: 'Response Time < 3s', enabled: true, passRate: 94 },
    { name: 'Sentiment Positive', enabled: true, passRate: 87 },
    { name: 'Escalation Protocol', enabled: true, passRate: 91 },
    { name: 'Closing Protocol', enabled: false, passRate: 0 }
  ]

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600'
    if (score >= 60) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getStatusBadge = (status) => {
    const styles = {
      passed: 'bg-green-100 text-green-700',
      flagged: 'bg-yellow-100 text-yellow-700',
      failed: 'bg-red-100 text-red-700'
    }
    return (
      <span className={`px-2.5 py-1 rounded-full text-xs font-medium capitalize ${styles[status]}`}>
        {status}
      </span>
    )
  }

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">AI Quality Assurance</h1>
          <p className="text-neutral-600">Monitor and improve your AI agent performance</p>
        </div>
        <div className="flex items-center gap-3">
          <select 
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="px-4 py-2.5 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <option value="24h">Last 24 hours</option>
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
          </select>
          <button className="inline-flex items-center gap-2 px-4 py-2.5 border border-neutral-300 rounded-xl hover:bg-neutral-50 font-medium text-neutral-700">
            <Download className="w-5 h-5" />
            Export Report
          </button>
        </div>
      </div>

      {/* Score Overview */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        <div className="bg-white rounded-2xl border border-neutral-200 p-6 col-span-2 lg:col-span-1">
          <div className="text-sm text-neutral-600 mb-2">Overall QA Score</div>
          <div className={`text-4xl font-bold ${getScoreColor(qaMetrics.overallScore)}`}>
            {qaMetrics.overallScore}%
          </div>
          <div className="flex items-center gap-1 mt-2 text-sm text-green-600">
            <TrendingUp className="w-4 h-4" />
            +3% from last week
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-neutral-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-neutral-600">Reviewed</span>
            <MessageSquare className="w-5 h-5 text-neutral-400" />
          </div>
          <div className="text-2xl font-bold text-neutral-900">{qaMetrics.totalReviewed}</div>
        </div>

        <div className="bg-white rounded-2xl border border-neutral-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-neutral-600">Passed</span>
            <CheckCircle className="w-5 h-5 text-green-500" />
          </div>
          <div className="text-2xl font-bold text-green-600">{qaMetrics.passed}</div>
        </div>

        <div className="bg-white rounded-2xl border border-neutral-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-neutral-600">Flagged</span>
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
          </div>
          <div className="text-2xl font-bold text-yellow-600">{qaMetrics.flagged}</div>
        </div>

        <div className="bg-white rounded-2xl border border-neutral-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-neutral-600">Failed</span>
            <XCircle className="w-5 h-5 text-red-500" />
          </div>
          <div className="text-2xl font-bold text-red-600">{qaMetrics.failed}</div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Reviews */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-neutral-200">
          <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-neutral-900">Recent Reviews</h2>
            <button className="text-sm text-primary-600 hover:underline">View All</button>
          </div>
          
          <div className="divide-y divide-neutral-100">
            {recentReviews.map((review) => (
              <div key={review.id} className="p-6 hover:bg-neutral-50 transition-colors cursor-pointer">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      review.type === 'voice' ? 'bg-green-100' : 'bg-blue-100'
                    }`}>
                      {review.type === 'voice' ? (
                        <Phone className="w-5 h-5 text-green-600" />
                      ) : (
                        <MessageSquare className="w-5 h-5 text-blue-600" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium text-neutral-900">{review.agent}</p>
                      <p className="text-sm text-neutral-500">{review.conversationId} • {review.timestamp}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className={`text-2xl font-bold ${getScoreColor(review.score)}`}>
                      {review.score}
                    </div>
                    {getStatusBadge(review.status)}
                  </div>
                </div>
                
                {review.issues.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {review.issues.map((issue, idx) => (
                      <span key={idx} className="px-2.5 py-1 bg-red-50 text-red-700 text-xs rounded-full">
                        {issue}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* QA Rules */}
        <div className="bg-white rounded-2xl border border-neutral-200">
          <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-neutral-900">QA Rules</h2>
            <button className="text-sm text-primary-600 hover:underline">Configure</button>
          </div>
          
          <div className="p-6 space-y-4">
            {qaRules.map((rule, idx) => (
              <div key={idx} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${rule.enabled ? 'bg-green-500' : 'bg-neutral-300'}`} />
                  <span className={`text-sm ${rule.enabled ? 'text-neutral-900' : 'text-neutral-400'}`}>
                    {rule.name}
                  </span>
                </div>
                {rule.enabled && (
                  <span className={`text-sm font-medium ${getScoreColor(rule.passRate)}`}>
                    {rule.passRate}%
                  </span>
                )}
              </div>
            ))}
          </div>

          <div className="p-6 border-t border-neutral-100">
            <button className="w-full px-4 py-2.5 border border-neutral-300 rounded-xl hover:bg-neutral-50 font-medium text-neutral-700 text-sm">
              Add New Rule
            </button>
          </div>
        </div>
      </div>

      {/* Tips */}
      <div className="mt-8 bg-gradient-to-r from-primary-50 to-purple-50 rounded-2xl border border-primary-100 p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center flex-shrink-0">
            <Shield className="w-5 h-5 text-primary-600" />
          </div>
          <div>
            <h3 className="font-semibold text-neutral-900 mb-1">Improve Your QA Score</h3>
            <p className="text-neutral-600 text-sm">
              Based on recent reviews, consider updating your agent's response time settings and adding more specific guidelines for information accuracy.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default QualityAssurancePage
