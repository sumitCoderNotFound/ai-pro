import { useState } from 'react'
import { Link } from 'react-router-dom'
import { 
  PhoneCall, 
  Plus, 
  Upload, 
  Play, 
  Pause, 
  Clock,
  CheckCircle,
  XCircle,
  Users,
  FileSpreadsheet,
  ArrowRight,
  MoreVertical,
  Trash2,
  Eye
} from 'lucide-react'

const BatchCallsPage = () => {
  const [campaigns, setCampaigns] = useState([
    {
      id: 1,
      name: 'Q1 Lead Follow-up',
      status: 'completed',
      totalCalls: 250,
      completed: 250,
      successful: 218,
      failed: 32,
      agent: 'Sales Assistant',
      createdAt: '2024-01-15',
      completedAt: '2024-01-16'
    },
    {
      id: 2,
      name: 'Customer Satisfaction Survey',
      status: 'in_progress',
      totalCalls: 500,
      completed: 312,
      successful: 287,
      failed: 25,
      agent: 'Survey Bot',
      createdAt: '2024-01-20',
      completedAt: null
    },
    {
      id: 3,
      name: 'Appointment Reminders',
      status: 'scheduled',
      totalCalls: 150,
      completed: 0,
      successful: 0,
      failed: 0,
      agent: 'Reminder Agent',
      createdAt: '2024-01-22',
      scheduledFor: '2024-01-25 09:00 AM'
    }
  ])

  const getStatusBadge = (status) => {
    const styles = {
      completed: 'bg-green-100 text-green-700',
      in_progress: 'bg-blue-100 text-blue-700',
      scheduled: 'bg-yellow-100 text-yellow-700',
      paused: 'bg-neutral-100 text-neutral-700',
      failed: 'bg-red-100 text-red-700'
    }
    const labels = {
      completed: 'Completed',
      in_progress: 'In Progress',
      scheduled: 'Scheduled',
      paused: 'Paused',
      failed: 'Failed'
    }
    return (
      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${styles[status]}`}>
        {labels[status]}
      </span>
    )
  }

  const getProgressPercentage = (campaign) => {
    if (campaign.totalCalls === 0) return 0
    return Math.round((campaign.completed / campaign.totalCalls) * 100)
  }

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Batch Calls</h1>
          <p className="text-neutral-600">Create and manage automated calling campaigns</p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary-600 text-white rounded-xl hover:bg-primary-700 font-medium">
          <Plus className="w-5 h-5" />
          New Campaign
        </button>
      </div>

      {/* Stats Overview */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-2xl border border-neutral-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-neutral-600">Total Campaigns</span>
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <PhoneCall className="w-5 h-5 text-blue-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-neutral-900">{campaigns.length}</div>
        </div>
        
        <div className="bg-white rounded-2xl border border-neutral-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-neutral-600">Active Campaigns</span>
            <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
              <Play className="w-5 h-5 text-green-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-neutral-900">
            {campaigns.filter(c => c.status === 'in_progress').length}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-neutral-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-neutral-600">Total Calls Made</span>
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
              <Users className="w-5 h-5 text-purple-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-neutral-900">
            {campaigns.reduce((acc, c) => acc + c.completed, 0).toLocaleString()}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-neutral-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-neutral-600">Success Rate</span>
            <div className="w-10 h-10 bg-yellow-100 rounded-xl flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-yellow-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-neutral-900">
            {Math.round(
              (campaigns.reduce((acc, c) => acc + c.successful, 0) / 
               Math.max(campaigns.reduce((acc, c) => acc + c.completed, 0), 1)) * 100
            )}%
          </div>
        </div>
      </div>

      {/* Campaigns List */}
      <div className="bg-white rounded-2xl border border-neutral-200">
        <div className="p-6 border-b border-neutral-100">
          <h2 className="text-lg font-semibold text-neutral-900">Campaigns</h2>
        </div>

        {campaigns.length === 0 ? (
          <div className="p-12 text-center">
            <PhoneCall className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-neutral-900 mb-2">No campaigns yet</h3>
            <p className="text-neutral-500 mb-6">Create your first batch calling campaign</p>
            <button className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary-600 text-white rounded-xl hover:bg-primary-700 font-medium">
              <Plus className="w-5 h-5" />
              New Campaign
            </button>
          </div>
        ) : (
          <div className="divide-y divide-neutral-100">
            {campaigns.map((campaign) => (
              <div key={campaign.id} className="p-6 hover:bg-neutral-50 transition-colors">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                      <PhoneCall className="w-6 h-6 text-primary-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-neutral-900">{campaign.name}</h3>
                      <p className="text-sm text-neutral-500">Agent: {campaign.agent}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {getStatusBadge(campaign.status)}
                    <button className="p-2 hover:bg-neutral-100 rounded-lg">
                      <MoreVertical className="w-5 h-5 text-neutral-400" />
                    </button>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mb-4">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-neutral-600">Progress</span>
                    <span className="font-medium text-neutral-900">
                      {campaign.completed} / {campaign.totalCalls} calls ({getProgressPercentage(campaign)}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-neutral-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary-500 rounded-full transition-all duration-500"
                      style={{ width: `${getProgressPercentage(campaign)}%` }}
                    />
                  </div>
                </div>

                {/* Stats Row */}
                <div className="flex items-center gap-6 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span className="text-neutral-600">{campaign.successful} successful</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <XCircle className="w-4 h-4 text-red-500" />
                    <span className="text-neutral-600">{campaign.failed} failed</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-neutral-400" />
                    <span className="text-neutral-600">Created {campaign.createdAt}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Start Guide */}
      <div className="mt-8 bg-gradient-to-r from-primary-50 to-purple-50 rounded-2xl border border-primary-100 p-6">
        <h3 className="font-semibold text-neutral-900 mb-2">Getting Started with Batch Calls</h3>
        <p className="text-neutral-600 text-sm mb-4">
          Upload a CSV with phone numbers, select an agent, and schedule your campaign.
        </p>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center gap-2 text-sm text-neutral-700">
            <div className="w-6 h-6 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 text-xs font-bold">1</div>
            <span>Upload contacts (CSV)</span>
          </div>
          <ArrowRight className="w-4 h-4 text-neutral-300 hidden sm:block" />
          <div className="flex items-center gap-2 text-sm text-neutral-700">
            <div className="w-6 h-6 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 text-xs font-bold">2</div>
            <span>Select AI agent</span>
          </div>
          <ArrowRight className="w-4 h-4 text-neutral-300 hidden sm:block" />
          <div className="flex items-center gap-2 text-sm text-neutral-700">
            <div className="w-6 h-6 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 text-xs font-bold">3</div>
            <span>Schedule & launch</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default BatchCallsPage
