import { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { agentsApi } from '@/services/api'
import {
  ArrowLeft,
  Settings,
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  MessageSquare,
  Bot,
  Loader2,
  Save,
  Sparkles,
  Code,
  X,
  Info
} from 'lucide-react'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const getToken = () => localStorage.getItem('convohubai_access_token')

// ============================================
// TEST AUDIO PANEL (Right Side)
// ============================================
const TestAudioPanel = ({ agent }) => {
  const [activeTab, setActiveTab] = useState('audio') // 'audio' | 'chat' | 'json'
  const [isCallActive, setIsCallActive] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isAiSpeaking, setIsAiSpeaking] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [messages, setMessages] = useState([])
  const [currentTranscript, setCurrentTranscript] = useState('')
  
  const speechSynthRef = useRef(null)
  const recognitionRef = useRef(null)
  const messagesEndRef = useRef(null)

  // Initialize speech synthesis
  useEffect(() => {
    speechSynthRef.current = window.speechSynthesis
    return () => {
      if (speechSynthRef.current) {
        speechSynthRef.current.cancel()
      }
    }
  }, [])

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Speak text using Web Speech API
  const speakText = useCallback((text) => {
    return new Promise((resolve) => {
      if (!speechSynthRef.current) {
        resolve()
        return
      }
      
      speechSynthRef.current.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      
      const voices = speechSynthRef.current.getVoices()
      const preferredVoice = voices.find(v => 
        v.name.includes('Samantha') || 
        v.name.includes('Google') ||
        v.name.includes('Microsoft') ||
        v.lang.startsWith('en')
      ) || voices[0]
      
      if (preferredVoice) utterance.voice = preferredVoice
      utterance.rate = 1.0
      utterance.pitch = 1.0
      
      utterance.onstart = () => setIsAiSpeaking(true)
      utterance.onend = () => { setIsAiSpeaking(false); resolve() }
      utterance.onerror = () => { setIsAiSpeaking(false); resolve() }
      
      speechSynthRef.current.speak(utterance)
    })
  }, [])

  // Get AI response
  const getAIResponse = useCallback(async (userMessage) => {
    try {
      const conversationHistory = messages.map(m => ({
        role: m.role,
        content: m.content
      }))
      
      const response = await fetch(`${API_URL}/api/v1/agents/${agent.id}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify({
          message: userMessage,
          conversation_history: conversationHistory
        })
      })
      
      if (!response.ok) throw new Error('Failed to get response')
      const data = await response.json()
      return data.response || "I'm sorry, I couldn't process that."
      
    } catch (error) {
      console.error('AI Response error:', error)
      return "I'm having trouble connecting right now. Please try again."
    }
  }, [agent?.id, messages])

  // Process user speech
  const processUserSpeech = useCallback(async (transcript) => {
    if (!transcript.trim()) return
    
    setMessages(prev => [...prev, { role: 'user', content: transcript }])
    setCurrentTranscript('')
    
    const aiResponse = await getAIResponse(transcript)
    setMessages(prev => [...prev, { role: 'assistant', content: aiResponse }])
    
    await speakText(aiResponse)
    
    if (isCallActive && !isMuted) {
      startListening()
    }
  }, [getAIResponse, speakText, isCallActive, isMuted])

  // Start speech recognition
  const startListening = useCallback(() => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      console.error('Speech recognition not supported')
      return
    }
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    recognitionRef.current = new SpeechRecognition()
    recognitionRef.current.continuous = true
    recognitionRef.current.interimResults = true
    recognitionRef.current.lang = 'en-US'
    
    recognitionRef.current.onstart = () => setIsListening(true)
    
    recognitionRef.current.onresult = (event) => {
      let interimTranscript = ''
      let finalTranscript = ''
      
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript
        if (event.results[i].isFinal) {
          finalTranscript += transcript
        } else {
          interimTranscript += transcript
        }
      }
      
      if (finalTranscript) {
        recognitionRef.current?.stop()
        setIsListening(false)
        processUserSpeech(finalTranscript)
      } else {
        setCurrentTranscript(interimTranscript)
      }
    }
    
    recognitionRef.current.onerror = (event) => {
      if (event.error !== 'no-speech') setIsListening(false)
    }
    
    recognitionRef.current.onend = () => {
      if (isCallActive && !isMuted && !isAiSpeaking) {
        recognitionRef.current?.start()
      }
    }
    
    recognitionRef.current.start()
  }, [isCallActive, isMuted, isAiSpeaking, processUserSpeech])

  // Stop listening
  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
      recognitionRef.current = null
    }
    setIsListening(false)
  }, [])

  // Start call
  const startCall = async () => {
    setIsConnecting(true)
    setMessages([])
    
    await new Promise(resolve => setTimeout(resolve, 500))
    
    setIsCallActive(true)
    setIsConnecting(false)
    
    const firstMessage = agent?.welcome_message || 
      `Hello! Thank you for calling. I'm ${agent?.name || 'your assistant'}. How can I help you today?`
    
    setMessages([{ role: 'assistant', content: firstMessage }])
    await speakText(firstMessage)
    startListening()
  }

  // End call
  const endCall = () => {
    setIsCallActive(false)
    stopListening()
    if (speechSynthRef.current) speechSynthRef.current.cancel()
    setIsAiSpeaking(false)
    setCurrentTranscript('')
  }

  // Toggle mute
  const toggleMute = () => {
    if (isMuted) {
      setIsMuted(false)
      if (isCallActive && !isAiSpeaking) startListening()
    } else {
      setIsMuted(true)
      stopListening()
    }
  }

  return (
    <div className="w-96 border-l border-neutral-200 bg-white flex flex-col h-full">
      {/* Header Tabs */}
      <div className="border-b border-neutral-200">
        <div className="flex items-center justify-between px-4 pt-4 pb-2">
          <h3 className="font-semibold text-neutral-800">Global Settings</h3>
          <h3 className="font-bold text-neutral-900">Test Agent</h3>
        </div>
        
        <div className="flex px-4 gap-2 pb-3">
          <button
            onClick={() => setActiveTab('audio')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'audio'
                ? 'bg-neutral-100 text-neutral-900'
                : 'text-neutral-500 hover:bg-neutral-50'
            }`}
          >
            <Phone className="w-4 h-4" />
            Test Audio
          </button>
          <button
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'chat'
                ? 'bg-neutral-100 text-neutral-900'
                : 'text-neutral-500 hover:bg-neutral-50'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            Test Chat
          </button>
          <button
            onClick={() => setActiveTab('json')}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'json'
                ? 'bg-neutral-100 text-neutral-900'
                : 'text-neutral-500 hover:bg-neutral-50'
            }`}
          >
            <Code className="w-4 h-4" />
            {'{ }'}
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 flex flex-col">
        {activeTab === 'audio' && (
          <>
            {!isCallActive ? (
              /* Not in call - Show Test Button */
              <div className="flex-1 flex flex-col items-center justify-center p-8">
                <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center mb-4">
                  <Mic className="w-8 h-8 text-neutral-400" />
                </div>
                <h4 className="text-lg font-medium text-neutral-800 mb-2">Test your agent</h4>
                <div className="flex items-center gap-2 px-4 py-2 bg-neutral-100 rounded-full text-sm text-neutral-600 mb-6">
                  <Info className="w-4 h-4" />
                  <span>Please note call transfer is not supported in Webcall.</span>
                </div>
                <button
                  onClick={startCall}
                  disabled={isConnecting}
                  className="px-8 py-3 border-2 border-neutral-300 rounded-xl text-neutral-700 font-medium hover:bg-neutral-50 disabled:opacity-50 transition-colors"
                >
                  {isConnecting ? 'Connecting...' : 'Test'}
                </button>
              </div>
            ) : (
              /* In call - Show Conversation */
              <>
                <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-teal-50/30 to-white">
                  {messages.map((message, index) => (
                    <div
                      key={index}
                      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[85%] px-4 py-2.5 rounded-2xl ${
                        message.role === 'user'
                          ? 'bg-primary-500 text-white rounded-br-md'
                          : 'bg-white border border-neutral-200 text-neutral-800 rounded-bl-md shadow-sm'
                      }`}>
                        <p className="text-sm">{message.content}</p>
                      </div>
                    </div>
                  ))}
                  
                  {currentTranscript && (
                    <div className="flex justify-end">
                      <div className="max-w-[85%] px-4 py-2.5 rounded-2xl bg-primary-200 text-primary-800 rounded-br-md">
                        <p className="text-sm italic">{currentTranscript}...</p>
                      </div>
                    </div>
                  )}
                  
                  {isAiSpeaking && (
                    <div className="flex justify-start">
                      <div className="px-4 py-2.5 rounded-2xl bg-white border border-neutral-200 rounded-bl-md">
                        <div className="flex items-center gap-2">
                          <div className="flex gap-1">
                            <span className="w-2 h-2 bg-primary-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                            <span className="w-2 h-2 bg-primary-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                            <span className="w-2 h-2 bg-primary-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                          </div>
                          <span className="text-sm text-neutral-500">Speaking...</span>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Status */}
                <div className="px-4 py-2 bg-neutral-50 border-t border-neutral-200 text-center text-sm">
                  {isListening && (
                    <span className="text-green-600 flex items-center justify-center gap-2">
                      <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                      Listening...
                    </span>
                  )}
                  {isAiSpeaking && (
                    <span className="text-primary-600 flex items-center justify-center gap-2">
                      <Volume2 className="w-4 h-4 animate-pulse" />
                      AI Speaking...
                    </span>
                  )}
                </div>

                {/* Call Controls */}
                <div className="p-4 border-t border-neutral-200 flex items-center justify-center gap-4">
                  <button
                    onClick={toggleMute}
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                      isMuted 
                        ? 'bg-red-100 text-red-500 hover:bg-red-200' 
                        : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                    }`}
                  >
                    {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                  
                  <button
                    onClick={endCall}
                    className="w-14 h-14 rounded-full bg-red-500 text-white flex items-center justify-center hover:bg-red-600 transition-colors"
                  >
                    <PhoneOff className="w-6 h-6" />
                  </button>
                  
                  <button className="w-12 h-12 rounded-full bg-neutral-100 text-neutral-600 flex items-center justify-center hover:bg-neutral-200 transition-colors">
                    <Volume2 className="w-5 h-5" />
                  </button>
                </div>
              </>
            )}
          </>
        )}

        {activeTab === 'chat' && (
          <div className="flex-1 flex items-center justify-center p-8 text-neutral-500">
            <p>Chat testing coming soon...</p>
          </div>
        )}

        {activeTab === 'json' && (
          <div className="flex-1 p-4 overflow-auto">
            <pre className="text-xs bg-neutral-50 p-4 rounded-lg overflow-auto">
              {JSON.stringify(agent, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  )
}

// ============================================
// AGENT SETTINGS PANEL (Left Side)
// ============================================
const AgentSettingsPanel = ({ agent, onSave, isSaving }) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    system_prompt: '',
    welcome_message: '',
    llm_provider: 'groq',
    llm_model: 'llama-3.3-70b-versatile',
    temperature: 0.7,
    language: 'en-US',
  })

  useEffect(() => {
    if (agent) {
      setFormData({
        name: agent.name || '',
        description: agent.description || '',
        system_prompt: agent.system_prompt || '',
        welcome_message: agent.welcome_message || '',
        llm_provider: agent.llm_provider || 'groq',
        llm_model: agent.llm_model || 'llama-3.3-70b-versatile',
        temperature: agent.temperature || 0.7,
        language: agent.language || 'en-US',
      })
    }
  }, [agent])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    onSave(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto">
      {/* Agent Name */}
      <div>
        <label className="block text-sm font-medium text-neutral-700 mb-2">
          Agent Name
        </label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
        />
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-neutral-700 mb-2">
          Description
        </label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          rows={2}
          className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
        />
      </div>

      {/* Voice & Language */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-neutral-700 mb-2">
            Language
          </label>
          <select
            name="language"
            value={formData.language}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <option value="en-US">English (US)</option>
            <option value="en-GB">English (UK)</option>
            <option value="es-ES">Spanish</option>
            <option value="fr-FR">French</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-neutral-700 mb-2">
            Model
          </label>
          <select
            name="llm_model"
            value={formData.llm_model}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <option value="llama-3.3-70b-versatile">Llama 3.3 70B</option>
            <option value="llama-3.1-8b-instant">Llama 3.1 8B</option>
            <option value="mixtral-8x7b-32768">Mixtral 8x7B</option>
          </select>
        </div>
      </div>

      {/* Welcome Message */}
      <div>
        <label className="block text-sm font-medium text-neutral-700 mb-2">
          Welcome Message (First thing AI says)
        </label>
        <textarea
          name="welcome_message"
          value={formData.welcome_message}
          onChange={handleChange}
          rows={3}
          placeholder="Hello! How can I help you today?"
          className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
        />
      </div>

      {/* System Prompt */}
      <div>
        <label className="block text-sm font-medium text-neutral-700 mb-2">
          Global Prompt (System Instructions)
        </label>
        <textarea
          name="system_prompt"
          value={formData.system_prompt}
          onChange={handleChange}
          rows={8}
          placeholder="You are a helpful AI assistant..."
          className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none font-mono text-sm"
        />
      </div>

      {/* Temperature */}
      <div>
        <label className="block text-sm font-medium text-neutral-700 mb-2">
          Temperature: {formData.temperature}
        </label>
        <input
          type="range"
          name="temperature"
          value={formData.temperature}
          onChange={handleChange}
          min="0"
          max="1"
          step="0.1"
          className="w-full"
        />
      </div>

      {/* Save Button */}
      <button
        type="submit"
        disabled={isSaving}
        className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-primary-600 text-white rounded-xl hover:bg-primary-700 disabled:opacity-50 transition-colors"
      >
        {isSaving ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <Save className="w-5 h-5" />
        )}
        Save Changes
      </button>
    </form>
  )
}

// ============================================
// MAIN AGENT DETAIL PAGE
// ============================================
const AgentDetailPage = () => {
  const { agentId } = useParams()
  const navigate = useNavigate()
  const [agent, setAgent] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState('')

  // Fetch agent
  useEffect(() => {
    const fetchAgent = async () => {
      try {
        setIsLoading(true)
        const data = await agentsApi.get(agentId)
        setAgent(data)
      } catch (err) {
        setError('Failed to load agent')
        console.error(err)
      } finally {
        setIsLoading(false)
      }
    }
    fetchAgent()
  }, [agentId])

  // Save agent
  const handleSave = async (data) => {
    setIsSaving(true)
    try {
      const updated = await agentsApi.update(agentId, data)
      setAgent(updated)
    } catch (err) {
      setError('Failed to save changes')
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
      </div>
    )
  }

  if (error || !agent) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-red-500">{error || 'Agent not found'}</p>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-neutral-50">
      {/* Left Panel - Settings */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-white">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/dashboard/agents')}
              className="p-2 hover:bg-neutral-100 rounded-lg"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-purple-500 rounded-xl flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-semibold text-neutral-900">{agent.name}</h1>
                <p className="text-sm text-neutral-500">{agent.agent_type || 'AI Agent'}</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-neutral-500">
            <span>Agent ID: {agent.id?.substring(0, 8)}...</span>
          </div>
        </div>

        {/* Settings Form */}
        <div className="flex-1 overflow-y-auto">
          <AgentSettingsPanel 
            agent={agent} 
            onSave={handleSave} 
            isSaving={isSaving}
          />
        </div>
      </div>

      {/* Right Panel - Test Audio */}
      <TestAudioPanel agent={agent} />
    </div>
  )
}

export default AgentDetailPage